#!/bin/bash

# Конфигурация
CONFIG_FILE="/etc/backup_items.conf"  # Файл со списком элементов для резервного копирования
REMOTE_USER="root"
REMOTE_HOST="backupmanager.vpn"
REMOTE_DIR="/root/backup/$HOSTNAME"  # Каталог на удалённом сервере
LOCAL_BACKUP_DIR="/tmp/backups"
MAX_REMOTE_BACKUPS=5

# Настройки логирования
LOG_DIR="/var/log/backup_scripts"
LOG_FILE="$LOG_DIR/$(basename "$0").log"
MAX_LOG_SIZE=1048576
MAX_LOG_FILES=5

# Создаём локальные директории
mkdir -p "$LOCAL_BACKUP_DIR"
mkdir -p "$LOG_DIR"

# Функция для чтения элементов из файла конфигурации
read_backup_items() {
    local items=()
    
    # Проверяем существование файла конфигурации
    if [ ! -f "$CONFIG_FILE" ]; then
        log "Ошибка: файл конфигурации $CONFIG_FILE не найден!"
        exit 1
    fi
    
    # Читаем файл, игнорируя комментарии и пустые строки
    while IFS= read -r line; do
        # Удаляем комментарии и лишние пробелы
        line=$(echo "$line" | sed 's/#.*$//' | xargs)
        
        # Если строка не пустая, добавляем в массив
        if [ -n "$line" ]; then
            items+=("$line")
        fi
    done < "$CONFIG_FILE"
    
    # Проверяем, что есть элементы для резервного копирования
    if [ ${#items[@]} -eq 0 ]; then
        log "Ошибка: в файле конфигурации $CONFIG_FILE не указаны элементы для резервного копирования!"
        exit 1
    fi
    
    echo "${items[@]}"
}

# Функция для ротации логов
rotate_logs() {
    if [ -f "$LOG_FILE" ] && [ $(stat -c%s "$LOG_FILE") -ge $MAX_LOG_SIZE ]; then
        echo "Ротируем логи..."
        for i in $(seq $MAX_LOG_FILES -1 2); do
            [ -f "${LOG_FILE}.$((i-1))" ] && mv "${LOG_FILE}.$((i-1))" "${LOG_FILE}.$i"
        done
        mv "$LOG_FILE" "${LOG_FILE}.1"
    fi
}

# Функция для создания каталога на удалённом сервере
create_remote_dir() {
    log "Проверка существования каталога $REMOTE_DIR на $REMOTE_HOST..."
    if ! ssh "$REMOTE_USER@$REMOTE_HOST" "[ -d '$REMOTE_DIR' ]" 2>>"$LOG_FILE"; then
        log "Каталог не существует, создаём..."
        if ! ssh "$REMOTE_USER@$REMOTE_HOST" "mkdir -p '$REMOTE_DIR'" 2>>"$LOG_FILE"; then
            log "Ошибка: не удалось создать каталог $REMOTE_DIR на $REMOTE_HOST!"
            exit 1
        fi
        log "Каталог $REMOTE_DIR успешно создан на $REMOTE_HOST"
    else
        log "Каталог $REMOTE_DIR уже существует на $REMOTE_HOST"
    fi
}

# Функция для ротации бэкапов
rotate_remote_backups() {
    log "Проверка ротации бэкапов на удалённом сервере (максимум $MAX_REMOTE_BACKUPS)..."
    ssh "$REMOTE_USER@$REMOTE_HOST" "cd '$REMOTE_DIR' && \
        ls -t | grep 'backup_$(hostname)' | tail -n +$(($MAX_REMOTE_BACKUPS + 1)) | \
        xargs -d '\n' rm -f --" 2>>"$LOG_FILE"

    if [ $? -eq 0 ]; then
        log "Ротация бэкапов на удалённом сервере выполнена успешно"
    else
        log "Ошибка при ротации бэкапов на удалённом сервере"
    fi
}

# Функция для проверки символьных ссылок
resolve_symlinks() {
    local items=()
    for item in "${ITEMS_TO_BACKUP[@]}"; do
        if [ -L "$item" ]; then
            items+=("$item")
            target=$(readlink -f "$item")
            items+=("$target")
            log "Обнаружена символьная ссылка: $item -> $target"
        else
            items+=("$item")
        fi
    done
    printf "%s\n" "${items[@]}" | sort -u
}

# Функция логирования
log() {
    local timestamp=$(date +"%Y-%m-%d %H:%M:%S")
    echo "[$timestamp] $1" | tee -a "$LOG_FILE"
}

# Начинаем работу
rotate_logs
log "=== Начало выполнения резервного копирования ==="
log "Хост: $(hostname)"
log "Пользователь: $(whoami)"

# Читаем элементы для резервного копирования из файла
ITEMS_TO_BACKUP=($(read_backup_items))
log "Прочитаны элементы для резервного копирования из файла $CONFIG_FILE:"
printf "  %s\n" "${ITEMS_TO_BACKUP[@]}" | tee -a "$LOG_FILE"

# Проверяем/создаём каталог на удалённом сервере
create_remote_dir

# Формируем имя архива
BACKUP_NAME="backup_$(hostname)_$(date +'%Y-%m-%d_%H-%M-%S').tar.gz"
BACKUP_PATH="$LOCAL_BACKUP_DIR/$BACKUP_NAME"

# Обрабатываем символьные ссылки
RESOLVED_ITEMS=($(resolve_symlinks))

# Логируем информацию о бэкапе
log "Создаём архив: $BACKUP_PATH"
log "Архивируемые элементы (с учётом символьных ссылок):"
printf "  %s\n" "${RESOLVED_ITEMS[@]}" | tee -a "$LOG_FILE"

# Проверка существования элементов
missing_items=()
for item in "${RESOLVED_ITEMS[@]}"; do
    if [ ! -e "$item" ]; then
        missing_items+=("$item")
        log "Предупреждение: элемент не существует - $item"
    fi
done

if [ ${#missing_items[@]} -gt 0 ]; then
    log "Внимание: ${#missing_items[@]} элементов не найдено, но продолжается работа"
fi

# Создаём архив с сохранением символьных ссылок
log "Начало создания архива (с сохранением символьных ссылок)..."
if ! tar -czh -f "$BACKUP_PATH" "${RESOLVED_ITEMS[@]}" 2>>"$LOG_FILE"; then
    log "Ошибка: не удалось создать архив!"
    exit 1
fi

# Проверяем архив
if [ ! -f "$BACKUP_PATH" ]; then
    log "Критическая ошибка: архив не был создан!"
    exit 1
fi

archive_size=$(du -h "$BACKUP_PATH" | cut -f1)
file_count=$(tar -tzf "$BACKUP_PATH" | wc -l)
symlink_count=$(tar -tzvf "$BACKUP_PATH" | grep '^l' | wc -l)
log "Архив успешно создан. Размер: $archive_size. Файлов в архиве: $file_count (симв. ссылок: $symlink_count)"

# Копируем на удалённый сервер
log "Начало копирования на $REMOTE_HOST..."
if ! scp "$BACKUP_PATH" "$REMOTE_USER@$REMOTE_HOST:$REMOTE_DIR" >>"$LOG_FILE" 2>&1; then
    log "Ошибка: не удалось скопировать архив на удалённый сервер!"
    exit 1
fi

log "Копирование успешно завершено. Архив сохранён на $REMOTE_HOST:$REMOTE_DIR/$BACKUP_NAME"

# Ротация старых бэкапов на удалённом сервере
rotate_remote_backups

# Очистка локального архива
log "Удаление локальной копии архива..."
rm "$BACKUP_PATH"
if [ $? -eq 0 ]; then
    log "Локальный архив удалён"
else
    log "Ошибка при удалении локального архива"
fi

log "=== Резервное копирование успешно завершено за $SECONDS секунд ==="
